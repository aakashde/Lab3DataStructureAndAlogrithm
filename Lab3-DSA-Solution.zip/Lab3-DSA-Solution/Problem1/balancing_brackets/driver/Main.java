package com.balancing_brackets.driver;

import java.util.Scanner;
import com.balancing_brackets.service.BalancingBracketImplementation;

public class Main {

	public static void main(String[] args) {
				
		Scanner sc = new Scanner(System.in);
		String input = sc.next();
		
		BalancingBracketImplementation bbI=new BalancingBracketImplementation();
		
		if(bbI.isBracketBalanced(input))
			System.out.println("The entered String has Balanced Brackets");
		else
			System.out.println("The entered Strings do not contain Balanced Brackets");
		
		sc.close();
	}

}
