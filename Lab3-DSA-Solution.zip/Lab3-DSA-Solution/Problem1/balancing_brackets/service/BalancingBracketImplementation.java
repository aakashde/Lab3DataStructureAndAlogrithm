package com.balancing_brackets.service;

import java.util.Stack;

public class BalancingBracketImplementation {

	public boolean isBracketBalanced(String inputExpression) {
		
		//function to implement the logic whether the brackets are balanced
		
		if(inputExpression.length()%2!=0)
			return false;
		
		Stack<Character> stack = new Stack<Character>();		
		for(int i=0;i<inputExpression.length();i++)
		{
			char currentChar = inputExpression.charAt(i);
			//if we encounter only opening sequences, we will add them into stack and
			//can skip further checks
			if(currentChar == '[' || currentChar == '{' || currentChar == '(')
			{
				stack.push(currentChar);
				continue;
			}
			
			if(stack.isEmpty())
				return false;
			
			//to check whether the closing pair of brackets matches
			char popResult;
			switch(currentChar)
			{
				case ']' :
					popResult = stack.pop();
					if(popResult == '}' || popResult == ')')
						return false;
							break;
							
				case '}' :
					popResult = stack.pop();
					if(popResult == ']' || popResult == ')')
						return false;
								break;
								
				case ')' :
					popResult = stack.pop();
					if(popResult == ']' || popResult == '}')
						return false;
								break;								
			}
		}
		
		if(stack.isEmpty())
			return true;
		
		return false;
	}

}
