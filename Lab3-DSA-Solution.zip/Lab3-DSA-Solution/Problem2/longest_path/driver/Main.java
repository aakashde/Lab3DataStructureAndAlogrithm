package com.longest_path.driver;

import java.util.ArrayList;
import com.longest_path.model.Node;
import com.longest_path.service.FindLongestPath;

public class Main {

	public static void main(String[] args) {
		
		//creating and building the tree
		Node root = new Node(100);
		root.leftNode = new Node(20);
		root.rightNode = new Node(130);
		root.leftNode.leftNode = new Node(10);
		root.leftNode.rightNode = new Node(50);
		root.rightNode.leftNode = new Node(110);
		root.rightNode.rightNode = new Node(140);
		root.leftNode.leftNode.leftNode = new Node(5);
		
		FindLongestPath fLP = new FindLongestPath();
		
		ArrayList<Integer> output = fLP.findLongestPath(root);
		int size = output.size();
		
		//printing the longest path from root to leaf
		System.out.println("Longest Path : ");
		System.out.print(output.get(size-1));
		for(int i=size-2;i>=0;i--)
		{
			System.out.print("->"+output.get(i));
		}
	}
}
