package com.longest_path.service;

import java.util.ArrayList;
import com.longest_path.model.Node;

public class FindLongestPath {

	public ArrayList<Integer> findLongestPath(Node root) {
		
		//base case for exit
		if(root == null)
		{
			ArrayList<Integer> output = new ArrayList<Integer>();
			return output;			
		}
		
		//recursive call on right sub-tree
		ArrayList<Integer> rightNode = findLongestPath(root.rightNode);
		
		//recursive call on left sub-tree
		ArrayList<Integer> leftNode = findLongestPath(root.leftNode);
		
		//building up of the arrayList as per the size comparison
		if(rightNode.size()<leftNode.size())
			leftNode.add(root.nodeData);
		else
			rightNode.add(root.nodeData);
		
		
		//going to left or right node as per the size
		return(leftNode.size()>rightNode.size()?leftNode:rightNode);
	}
}
